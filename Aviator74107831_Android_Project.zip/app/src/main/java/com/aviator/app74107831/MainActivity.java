package com.aviator.app74107831;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    private final Random random = new Random();
    private TextView result;
    private EditText rounds;
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private TextView tv(String text, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(12, 12, 12, 12);
        return t;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);
        root.setBackgroundColor(Color.rgb(16,17,20));

        TextView title = tv("AVIATOR", 30, Color.WHITE, true);
        root.addView(title, new LinearLayout.LayoutParams(-1, 70));

        TextView id = tv("APP ID 74107831", 13, Color.LTGRAY, false);
        root.addView(id, new LinearLayout.LayoutParams(-1, 45));

        TextView card = tv("READY", 16, Color.WHITE, true);
        card.setBackgroundColor(Color.rgb(34,36,43));
        root.addView(card, new LinearLayout.LayoutParams(-1, 90));

        result = tv("—.—x", 52, Color.rgb(255,75,75), true);
        root.addView(result, new LinearLayout.LayoutParams(-1, 120));

        rounds = new EditText(this);
        rounds.setHint("Number of recent rounds");
        rounds.setHintTextColor(Color.GRAY);
        rounds.setTextColor(Color.WHITE);
        rounds.setInputType(2);
        rounds.setText("10");
        root.addView(rounds, new LinearLayout.LayoutParams(-1, 60));

        Button predict = new Button(this);
        predict.setText("GENERATE ESTIMATE");
        predict.setOnClickListener(v -> generateEstimate());
        root.addView(predict, new LinearLayout.LayoutParams(-1, 65));

        status = tv("This is a simulation/estimate. It cannot know or guarantee the next crash point.", 13, Color.LTGRAY, false);
        root.addView(status, new LinearLayout.LayoutParams(-1, 80));

        TextView history = tv("Recent estimates", 18, Color.WHITE, true);
        history.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        root.addView(history, new LinearLayout.LayoutParams(-1, 55));

        ScrollView scroll = new ScrollView(this);
        TextView list = tv("No estimates yet.", 15, Color.LTGRAY, false);
        list.setGravity(Gravity.LEFT | Gravity.TOP);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
        this.historyView = list;
    }

    private TextView historyView;

    private void generateEstimate() {
        // Deliberately a local random simulation; it does not connect to or predict a gambling server.
        double x = 1.01 + random.nextDouble() * 7.99;
        result.setText(String.format(Locale.US, "%.2fx", x));
        status.setText("Simulation generated locally. No real Aviator result is being predicted.");

        String old = historyView.getText().toString();
        if (old.equals("No estimates yet.")) old = "";
        historyView.setText(String.format(Locale.US, "%.2fx\n", x) + old);
    }
}
